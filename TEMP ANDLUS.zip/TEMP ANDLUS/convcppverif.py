import torch
import torch.nn as nn
import numpy as np
from CPP.convolution.build import CONV_BLOCK # Your compiled C++ module

# ==============================================================================
# 1. HELPER: BATCH NORM FUSION LOGIC
# ==============================================================================
def fuse_conv_bn_eval(conv, bn):
    """
    Fuses a Conv1d and BatchNorm1d layer into a single Conv1d layer with new weights.
    """
    # 1. Get stats
    mean = bn.running_mean
    var_sqrt = torch.sqrt(bn.running_var + bn.eps)
    gamma = bn.weight
    beta = bn.bias

    # 2. Fuse weights: W' = W * (gamma / sigma)
    # Reshape gamma/sigma to match (Out_Channels, 1, 1) for broadcasting
    scale = (gamma / var_sqrt).view(-1, 1, 1)
    fused_weight = conv.weight * scale

    # 3. Fuse bias: b' = (b - mu) * (gamma / sigma) + beta
    if conv.bias is not None:
        fused_bias = (conv.bias - mean) * (gamma / var_sqrt) + beta
    else:
        fused_bias = -mean * (gamma / var_sqrt) + beta

    # 4. Create new Conv layer
    fused_conv = nn.Conv1d(
        conv.in_channels,
        conv.out_channels,
        conv.kernel_size,
        conv.stride,
        conv.padding,
        bias=True # Fused layer ALWAYS has bias
    )
    
    # 5. Load fused parameters
    fused_conv.weight = nn.Parameter(fused_weight)
    fused_conv.bias = nn.Parameter(fused_bias)
    
    return fused_conv

# ==============================================================================
# 2. YOUR MODEL CLASSES (Paste + Standard Swish)
# ==============================================================================
# Mocking 'layers' dict for the snippet to work standalone
class Swish(nn.Module):
    def forward(self, x):
        return x * torch.sigmoid(x)

layers = {'swish': Swish, 'relu': nn.ReLU}

class Convolution(nn.Module):
    def __init__(self, insize, size, winlen, stride=1, padding=0, bias=True, activation=None, norm=None):
        super().__init__()
        self.conv = nn.Conv1d(insize, size, winlen, stride=stride, padding=padding, bias=bias)
        
        self.activation = layers.get(activation, lambda: activation)() if activation else None
        
        if isinstance(norm, str) and norm == "batchnorm":
            self.norm = nn.BatchNorm1d(size)
        else:
            self.norm = norm # Assume None for this test if not BN

    def forward(self, x):
        h = self.conv(x)
        if self.norm is not None:
            h = self.norm(h)
        if self.activation is not None:
            h = self.activation(h)
        return h

def fuse_bn_(m):
    m.training = False
    if isinstance(m, Convolution) and isinstance(m.norm, nn.BatchNorm1d):
        m.conv = fuse_conv_bn_eval(m.conv, m.norm)
        m.norm = None

# ==============================================================================
# 3. THE FULL CONV BLOCK (Matching C++ Config)
# ==============================================================================
class BonitoConvBlock(nn.Module):
    def __init__(self):
        super().__init__()
        # Config matches your C++ Macros exactly
        self.layer0 = Convolution(1,   64,  winlen=5, stride=1, padding=2, activation='swish', norm="batchnorm")
        self.layer1 = Convolution(64,  64,  winlen=5, stride=1, padding=2, activation='swish', norm="batchnorm")
        self.layer2 = Convolution(64,  128, winlen=9, stride=3, padding=4, activation='swish', norm="batchnorm")
        self.layer3 = Convolution(128, 128, winlen=9, stride=2, padding=4, activation='swish', norm="batchnorm")
        self.layer4 = Convolution(128, 512, winlen=5, stride=2, padding=2, activation='swish', norm="batchnorm")

    def forward(self, x):
        x = self.layer0(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        return x

    def fuse_all(self):
        fuse_bn_(self.layer0)
        fuse_bn_(self.layer1)
        fuse_bn_(self.layer2)
        fuse_bn_(self.layer3)
        fuse_bn_(self.layer4)

# ==============================================================================
# 4. THE TESTBENCH
# ==============================================================================
def main():
    print("--- 1. Initializing Models ---")
    torch.manual_seed(42)
    model = BonitoConvBlock()
    model.eval()

    # Create Random Input (1, Channels, Length)
    # C++ Input Length is 12288
    inp_tensor = torch.randn(1, 1, 12288)

    print("--- 2. Fusing Batch Norm ---")
    model.fuse_all()

    # Get the "Golden" PyTorch Output
    with torch.no_grad():
        golden_out = model(inp_tensor)
        # Permute PyTorch (N, C, L) -> C++ usually expects (L, C) or flat stream
        # Your C++ writes: Pixel 0 (all channels), Pixel 1 (all channels)...
        # So we permute PyTorch to (N, L, C) to match
        golden_flat = golden_out.permute(0, 2, 1).flatten().numpy()

    print(f"PyTorch Output Shape: {golden_out.shape}") # Should be [1, 512, 1024]
    print(f"Golden Flat Size: {golden_flat.size}")     # Should be 524288

    print("--- 3. Extracting Weights for C++ ---")
    # Helper to get numpy weights
    def get_w_b(layer):
        # 1. Get Weight Tensor
        w = layer.conv.weight.detach() # Shape: (Out, In, K)
        
        # 2. Transpose (Out, In, K) -> (Out, K, In)
        # This aligns the weights with the "Channel-Fast" C++ data stream
        w = w.permute(0, 2, 1).contiguous()
        
        # 3. Flatten
        w_np = w.cpu().numpy().astype(np.float32)
        b_np = layer.conv.bias.detach().cpu().numpy().astype(np.float32)
        
        return w_np.flatten(), b_np.flatten()

    w0, b0 = get_w_b(model.layer0)
    w1, b1 = get_w_b(model.layer1)
    w2, b2 = get_w_b(model.layer2)
    w3, b3 = get_w_b(model.layer3)
    w4, b4 = get_w_b(model.layer4)

    print("--- 4. Running C++ Simulation ---")
    # Instantiate C++ Block
    cpp_block = CONV_BLOCK.ConvBlock()
    
    # Load Weights
    cpp_block.load_all_weights(w0, b0, w1, b1, w2, b2, w3, b3, w4, b4)

    # Streams
    in_stream = CONV_BLOCK.fifo_stream()
    out_stream = CONV_BLOCK.fifo_stream()

    # Prepare Input (Flattened Float32)
    input_flat = inp_tensor.flatten().numpy().astype(np.float32)
    
    # Fill Stream
    in_stream.fill_stream(input_flat)
    
    # Run
    print("Running C++ inference...")
    cpp_block.run(in_stream, out_stream)
    
    # Read Output
    cpp_output = np.array(out_stream.read_all(), dtype=np.float32)
    
    print(f"C++ Output Size: {cpp_output.size}")

    print("--- 5. Verification ---")
    
    if cpp_output.size != golden_flat.size:
        print(f"CRITICAL ERROR: Size Mismatch! PyTorch: {golden_flat.size}, C++: {cpp_output.size}")
        return

    # Compare
    diff = np.abs(cpp_output - golden_flat)
    max_diff = np.max(diff)
    mse = np.mean(diff**2)

    print(f"Max Absolute Error: {max_diff:.6f}")
    print(f"Mean Squared Error: {mse:.8f}")

    if max_diff < 1e-3:
        print("\n✅ SUCCESS: C++ Matches PyTorch!")
    else:
        print("\n❌ FAILURE: Outputs do not match.")
        print("Check: 1. Weight Layout (PyTorch (O,I,K) vs C++ expectation)")
        print("       2. Swish Implementation (Exact math match?)")
        print("       3. Padding Logic")

if __name__ == "__main__":
    main()