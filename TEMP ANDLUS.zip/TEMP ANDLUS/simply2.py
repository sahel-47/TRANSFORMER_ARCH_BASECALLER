import matplotlib.pyplot as plt
import numpy as np

# Parameters for Bonito
window_size = 256
dim = 512
sequences = np.arange(256, 4096, 128) # Test Seq Lengths from 256 to 4096

# 1. Standard "Dense" Attention (Generic Implementation)
# Complexity: N * N * Dim
ops_dense = sequences**2 * dim 

# 2. Your "Windowed" Attention (Custom Implementation)
# Complexity: N * Window * Dim
ops_window = sequences * window_size * dim

# Calculate Wasted Compute in Standard Model
# (Ops that are calculated but then masked out)
waste_percent = 100 * (1 - (ops_window / ops_dense))

# --- Specific Calculation for 1024 ---
target_seq = 1024
target_waste = 100 * (1 - ((target_seq * window_size * dim) / (target_seq**2 * dim)))

# --- PLOTTING ---
fig, ax1 = plt.subplots(figsize=(10, 6))

color = 'tab:red'
ax1.set_xlabel('Sequence Length (Tokens)')
ax1.set_ylabel('Operations (Billions)', color=color)
ax1.plot(sequences, ops_dense/1e9, color=color, linestyle='--', label='Standard Dense (FINN-T)')
ax1.plot(sequences, ops_window/1e9, color='tab:green', linewidth=3, label='Ours (Windowed)')
ax1.tick_params(axis='y', labelcolor=color)
ax1.legend(loc='upper left')
ax1.grid(True, alpha=0.3)

# Create a second y-axis to show the Efficiency Gain
ax2 = ax1.twinx()  
color = 'tab:blue'
ax2.set_ylabel('% Compute Wasted by Standard Model', color=color)  
ax2.plot(sequences, waste_percent, color=color, linewidth=2, label='% Wasted Ops in Dense')
ax2.tick_params(axis='y', labelcolor=color)
ax2.set_ylim(0, 100)

# --- Draw Line for 1024 ---
# Vertical line from x-axis to the blue curve
ax2.vlines(x=target_seq, ymin=0, ymax=target_waste, colors='gray', linestyles='dashed', alpha=0.7)
# Horizontal line from the blue curve to the y-axis
ax2.hlines(y=target_waste, xmin=256, xmax=target_seq, colors='gray', linestyles='dashed', alpha=0.7)

# Add a point at the intersection
ax2.plot(target_seq, target_waste, 'bo') 

# Annotation text
ax2.annotate(f'SeqLen={target_seq}\nWaste={target_waste:.1f}%', 
             xy=(target_seq, target_waste), 
             xytext=(target_seq + 200, target_waste - 15),
             arrowprops=dict(facecolor='black', shrink=0.05),
             fontsize=10,
             bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="gray", alpha=0.9))

plt.title(f'Scalability Analysis: Dense vs. Windowed Attention (Window={window_size})')
plt.show()