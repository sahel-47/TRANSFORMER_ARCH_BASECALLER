#include<nanobind/nanobind.h>
#include<vector>
#include<nanobind/ndarray.h>
#include<iostream>

namespace nb = nanobind;

template<typename T>
class DynamicArraySizing{

    public:

        T* tensor;
        int rows;
        int cols;

        DynamicArraySizing(int w, int h)
        : rows{w},
         cols{h}
         {
            tensor = new T[rows*cols];
         }

         void double_it()
         {
            for(int i = 0 ; i < rows*cols; i++)
            {
                tensor[i] *= 2;
              
            }
         }

         void initialize()
         {
            for(int i = 0 ; i < rows*cols; i++)
            {
                tensor[i] = i;
              
            }
         }

         ~DynamicArraySizing()
         {
            if(tensor) delete[] tensor;
         }

};


NB_MODULE(DynamicArray, m)
{
    nb::class_<DynamicArraySizing<int>>(m, "DynamicArray")
    .def(nb::init<int, int>())
    .def("get_tensor",[](DynamicArraySizing<int>& ARRAY)
    {   
        int* ptr = ARRAY.tensor;
        size_t rows = ARRAY.rows;
        size_t cols = ARRAY.cols;


        return nb::ndarray<int, nb::numpy>(
            ptr,
            {rows, cols},
            nb::cast(&ARRAY)
        );

    }
    )
    .def("double_it", &DynamicArraySizing<int>::double_it)
    .def("initialize", &DynamicArraySizing<int>::initialize);


}