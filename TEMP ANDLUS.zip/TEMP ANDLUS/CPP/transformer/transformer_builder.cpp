#include"transformer_block.hpp"
#include<nanobind/nanobind.h>
#include<nanobind/ndarray.h>

namespace nb = nanobind;

// TransformerEncoderBlock transformer_encoder_block(1024, 512, 8, 512, 2048, 512, 2.4494897);

NB_MODULE(TRANSFORMER_ENCODER_BLOCK, m)
{
    nb::class_<TransformerEncoderBlock>(m, "transformer_encoder_block")
    .def(nb::init<int , int, int, int, int, int, float>())
    .def("load_transformer_weights",[](TransformerEncoderBlock& TEB, 
                                       const nb::ndarray<>& WQ,
                                       const nb::ndarray<>& WK,
                                       const nb::ndarray<>& WV,
                                       const nb::ndarray<>& WO,
                                       const nb::ndarray<>& WRMS,
                                       const nb::ndarray<>& WH,
                                       const nb::ndarray<>& WG,
                                       const nb::ndarray<>& WOFFN,
                                       const nb::ndarray<>& WRMS2)
                                {

                                    float* ptr1 = static_cast<float*>(WQ.data());
                                    float* ptr2 = static_cast<float*>(WK.data());
                                    float* ptr3 = static_cast<float*>(WV.data());
                                    float* ptr4 = static_cast<float*>(WO.data());
                                    float* ptr5 = static_cast<float*>(WRMS.data());
                                    float* ptr6 = static_cast<float*>(WH.data());
                                    float* ptr7 = static_cast<float*>(WG.data());
                                    float* ptr8 = static_cast<float*>(WOFFN.data());
                                    float* ptr9 = static_cast<float*>(WRMS2.data());


                                    TEB.load_transformer_weights(ptr1, ptr2, ptr3, ptr4, ptr5, ptr6, ptr7, ptr8, ptr9);

                                }
                            )
    .def("get_layer_output",[](TransformerEncoderBlock& TEB)
        
        {
            float* output_ptr =  TEB.get_layer_output();

            size_t  shape[2] = {(size_t) TEB.get_seq_len(), (size_t) TEB.get_dim()};

            return nb::ndarray<nb::numpy, float>(output_ptr, 2, shape);
        },
        nb::rv_policy::reference_internal
    )

    .def("transformer_inference", [](TransformerEncoderBlock& TEB, nb::ndarray<>& input){

        float* float_ptr = static_cast<float*>(input.data());

        TEB.transformer_inference(float_ptr);
    }

);



}