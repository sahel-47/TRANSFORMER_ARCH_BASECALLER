#include<iostream>
#include<cmath>
#include<cstring>
#include<string.h>


#define DIM 512
#define WIN_SIZE_LEFT 127
#define WIN_SIZE_RIGHT 128
#define WIN_SIZE (WIN_SIZE_LEFT + 1 + WIN_SIZE_RIGHT)  //(127,128)

class RMSNorm // [TENSOR] --- (RMS NOM)/ +=RMS NORM([TENSOR] + [RESIDUAL])-----> RMS_NORMALIZED[TENSOR]
{

private:
    float m_eps; // SMALL VALUE TO BE ADDED TO DENOMINATOR TO MAKE IT NON ZERO in some cases
    // float *weight  // Should be passed to this function -- depends on number of features
    int m_seq_len; //Number of tokens
    int m_dim; //DIM of one token
    float* m_rms_norm_vector; // Depends on sequence length



public:
    void rms_norm(float *x, float *weight, float alpha_norm = 1.0,float* residual = nullptr) //func 1 - removing from func arg to class

    // x        -----> [SEQ_LEN, DIM]
    // weight   -----> [DIM]
    // residual -----> [SEQ_LEN, DIM] (optional)
    {

        if(residual)
        {
            for(int i = 0; i < m_seq_len; i++)
            {
                for(int j = 0; j < m_dim; j++)
                {
                    x[i*m_dim + j] =  x[i*m_dim + j] + residual[i*m_dim + j] * alpha_norm;
                }
            }
        }

        float sum = 0.0;

        for(int i = 0; i < m_seq_len; i++) //computes RMS_norm vector for each token
        {
            for(int j = 0; j < m_dim; j++)
            {
                sum += x[i*m_dim + j] * x[i*m_dim + j];
            }

            float rms_norm_val = 1/std::sqrt(sum/m_dim+m_eps);

            m_rms_norm_vector[i] = rms_norm_val;

            sum = 0.0;
        }

        for(int i = 0; i < m_seq_len; i++)
        {
            for(int j = 0; j < m_dim; j++)
            {
                x[i * m_dim + j] = x[i * m_dim + j] * m_rms_norm_vector[i] * weight[j]; //x itself will change
            }
        }


    }


    RMSNorm(int seq_len, int dim)
    :m_eps{1e-5},
    m_dim{dim},
    m_seq_len{seq_len}
    {
        m_rms_norm_vector = new float[seq_len];
    }

    ~RMSNorm()
    {
        if(m_rms_norm_vector) delete[] m_rms_norm_vector;
    }

};


class RoPE // [Q,K] -----[ROPE]-----> Rotated[Q,K]
{

private:
    int m_dim;
    float m_base;
    int m_seq_len;
    int m_heads; //or n_heads
    int m_hdim;

    void hdim() // func1
    {
        m_hdim = m_dim/m_heads;
    }

public: 
    float* m_inv_freq;

    
    void compute_inv_freq() //func 2
    {
        for(int i = 0; i < m_hdim/2; i++)
        {
            m_inv_freq[i] = 1/std::pow(m_base, (float)(2*i)/(float)m_hdim);
        }
    }

    void rope(float* query ,float* key) // func 3
    {        

        for(int i = 0; i < m_seq_len; i++)
        {
            for(int j = 0 ; j < m_heads; j++)
            {
                int offset = (i * m_dim) + (j * m_hdim);
                for(int k = 0; k < m_hdim/2; k++)
                {
                    float freq_val = float(i) * m_inv_freq[k];
                    float cos_val = std::cos(freq_val);
                    float sin_val = std::sin(freq_val);

                    int idx1 = offset + k;
                    int idx2 = offset + m_hdim/2 + k;

                    float x1 = query[idx1];
                    float y1 = query[idx2];

                    query[idx1] = x1*cos_val - y1*sin_val;
                    query[idx2] = y1*cos_val + x1*sin_val;

                    float x2 = key[idx1];
                    float y2 = key[idx2];

                    key[idx1] = x2*cos_val - y2*sin_val;
                    key[idx2] = y2*cos_val + x2*sin_val;

                }
            }
        }

    }

    RoPE(int seq_len, int dim, int heads, float base = 10000.0)
    :m_seq_len{seq_len},
    m_dim{dim},
    m_heads{heads},
    m_base{base}
    {


        hdim();
        m_inv_freq = new float[m_hdim/2];
        compute_inv_freq();

    }

    ~RoPE()
    {
        if(m_inv_freq) delete[] m_inv_freq;
    }

};


void mtx_mul(float* in, float* out, float *w, int m, int n, int k) 
// For a [mxn] X [nxk] ---> [mxk] matrix mul
{
    for(int i = 0; i < m; i++)
    {
        for(int j = 0; j < k; j++)
        {
            float final_val = 0.0;
            for(int l = 0; l < n; l++)
            {
                final_val += in[i * n + l] * w[j * n + l];

            }

            out[i * k + j] = final_val;
        }
    }
}


template<int MAXSIZE>
void softmax(float* x)
{
    float buffer[MAXSIZE];
    float max_val = x[0];

    max:
    for(int i = 1; i < MAXSIZE; i++)
    {
        float x_i = x[i];
        
        if(x_i > max_val)
        {
            max_val = x_i;
        }
    }

    exp:
    for(int i = 0; i < MAXSIZE; i++)
    {
        float x_i = std::exp(x[i] - max_val);
        buffer[i] = x_i;
    }

    float sum = 0.0;
    sum:
    for(int i = 0; i < MAXSIZE; i++)
    {
        sum += buffer[i];
    }

    float inv_sum = 1.0/sum;

    sofmax:
    for(int i = 0; i < MAXSIZE; i++)
    {
        x[i] = buffer[i] * inv_sum;
    }

}

class MultiHeadAttention // 
{

private:
    int m_num_heads;
    int m_seq_len;
    int m_dim;
    int m_hdim;

    void hdim()
    {
        m_hdim = m_dim/m_num_heads;
    }


public:

    void attn_function(float* query, float* key, float* value, float* out)
    {
        for(int i = 0; i < m_seq_len; i++)
        {
            float attn_scores[WIN_SIZE]; // stores scores for one head at a time
            float wv[m_dim]; //Stores one full vector of Final weighted value
            std::memset(wv, 0, m_dim* sizeof(float));

            for(int j = 0; j < m_num_heads; j++)
            {
                int q_offset = i * m_dim + j * m_hdim;
                int start_key = i - WIN_SIZE_LEFT;

                for(int k = 0; k < WIN_SIZE; k++)
                {
                    int check = start_key + k;

                    if(check >= 0 && check < m_seq_len)
                    {
                        int k_idx = check * m_dim + j * m_hdim;
                        float attention_score = 0.0;

                        for(int l = 0; l < m_hdim; l++)
                        {
                            attention_score += query[q_offset + l] * key[k_idx + l];
                            
                        }

                        attention_score = attention_score/std::sqrt(m_hdim);
                        attn_scores[k] = attention_score;

                    }

                    else
                    {
                        attn_scores[k] = -10000.0;
                    }

                }

                softmax<WIN_SIZE>(attn_scores);
                int wv_idx = j * m_hdim;
                

                for(int k = 0; k < WIN_SIZE; k++)
                {
                    int check = start_key + k;

                    if(check >= 0 && check < m_seq_len)
                    {
                        int v_idx = check * m_dim + j * m_hdim;
                        float a = attn_scores[k];

                        for(int l = 0; l < m_hdim; l++)
                        {
                            wv[wv_idx + l] += a * value[v_idx + l];
                            
                        }
                    }

                }



            }

            for(int j = 0 ; j < m_dim; j++)
            {
                out[i*m_dim + j] = wv[j];
            }

        }



    }


    MultiHeadAttention(int num_heads, int seq_len, int dim)
    :m_dim{dim},
    m_seq_len{seq_len},
    m_num_heads{num_heads}
    {
        hdim();
    }

};

class AttentionBlock
{   

private:
    
    // int m_dim;
    int m_num_heads;
    float alpha_norm;
    // float alpha;

    RoPE rope_layer;
    MultiHeadAttention MHA;
    RMSNorm rmsnorm;



    //--------------------------------------------------------
    float* W_q = nullptr; //W1
    float* W_k = nullptr; // W2
    float* W_v = nullptr; //W3
    float* W_out = nullptr; //W4
    float* rms_weight = nullptr; //rms_weight

    float* intermediate_tensor_q;
    float* intermediate_tensor_k;
    float* intermediate_tensor_v;

    float* out1;





public:
    int m_seq_len; 
    int m_dim; 

    void attention_forward(float *x, float* out)
    {

        if(! W_q)
        {
            std::cerr<<"Load Weights before calling ATTENTION FUNCTION....";
        }
        mtx_mul(x, intermediate_tensor_q, W_q, m_seq_len, m_dim, m_dim);
        mtx_mul(x, intermediate_tensor_k, W_k, m_seq_len, m_dim, m_dim);
        mtx_mul(x, intermediate_tensor_v, W_v, m_seq_len, m_dim, m_dim);

        rope_layer.rope(intermediate_tensor_q, intermediate_tensor_k);
        MHA.attn_function(intermediate_tensor_q, intermediate_tensor_k, intermediate_tensor_v, out1);

        mtx_mul(out1, out, W_out, m_seq_len, m_dim, m_dim );

        rmsnorm.rms_norm(out, rms_weight, alpha_norm, x);

    }

    void load_attention_weights(float * WQ, float* WK, float* WV, float* WO, float* WRMS)
    {
        W_q = WQ;
        W_k = WK;
        W_v = WV;
        W_out = WO;
        rms_weight = WRMS;
         
    }


    AttentionBlock(int seq_len, int dim, int num_heads, float alpha = 2.4494897)
    :m_seq_len{seq_len},
    m_dim{dim},
    m_num_heads{num_heads},
    rope_layer(seq_len, dim, num_heads),
    MHA(num_heads, seq_len, dim),
    rmsnorm(seq_len, dim),
    alpha_norm{alpha}
    {
        int weight_size = seq_len * dim ;

       intermediate_tensor_q = new float[weight_size];
       intermediate_tensor_k = new float[weight_size];
       intermediate_tensor_v = new float[weight_size];
       out1 = new float[weight_size];

    }

    ~AttentionBlock()
    {
        if(intermediate_tensor_q) delete[] intermediate_tensor_q;
        if(intermediate_tensor_k) delete[] intermediate_tensor_k;
        if(intermediate_tensor_v) delete[] intermediate_tensor_v;
        if(out1) delete[] out1;
    }

};


class Gated_FFN
{
private:
    int m_seq_len;
    int m_in_features;
    int m_hidden_features;
    int m_out_features;
    // std::string m_activation;

    // Weights
    float* W_hidden;
    float* W_gate;
    float* W_output;

    //Intermediates
    float* matrix_proj;
    float* matrix_gate;
    // float* FFN_out;

    //layers

    RMSNorm rms_layer;
    float* rms_weight;
    float alpha_norm;

public:
    void FFN(float* x, float* out)
    {
        mtx_mul(x, matrix_proj, W_hidden, m_seq_len, m_in_features, m_hidden_features);
        mtx_mul(x, matrix_gate, W_gate, m_seq_len, m_in_features, m_hidden_features);

        swiglu(matrix_proj, matrix_gate);
        mtx_mul(matrix_proj, out, W_output, m_seq_len, m_hidden_features, m_out_features);
        rms_layer.rms_norm(out,  rms_weight, alpha_norm, x);


    }

    void load_FFN_weights(float* WH, float* WG, float* WO, float* rmsWeight)
    {
        W_hidden = WH;
        W_gate = WG;
        W_output = WO;
        rms_weight = rmsWeight;
    }


    void swiglu(float* matrix, float* gate)
    {
        for(int i = 0; i < m_seq_len; i++)
        {
            for(int j = 0; j < m_hidden_features; j++)
            {
                gate[i * m_hidden_features+j] *= (1.0/(1+std::exp(-gate[i * m_hidden_features+j])));
                matrix[i*m_hidden_features+j] *= gate[i*m_hidden_features+j];
            }
        }

    }

    Gated_FFN(int seq_len, int in_features, int hidden_features, int out_features, float alphanorm)
    :m_seq_len{seq_len},
    m_in_features{in_features},
    m_hidden_features{hidden_features},
    m_out_features{out_features},
    rms_layer(seq_len, in_features),
    alpha_norm{alphanorm}
    {


        unsigned int weight_size = seq_len * hidden_features;
        unsigned int weight_size2 = seq_len * out_features;

        matrix_proj = new float[weight_size];
        matrix_gate = new float[weight_size];
        // FFN_out = new float[weight_size2];


    }   


    ~Gated_FFN()
    {
        if(matrix_proj) delete[] matrix_proj;
        if(matrix_gate) delete[] matrix_gate;
        // if(FFN_out) delete[] FFN_out;
    }
};



class TransformerEncoderBlock
{
    private:
        AttentionBlock attnblock;
        Gated_FFN ffn;

        

       
    public:
     float* layer_intermediate;
     float* layer_output;


        void load_transformer_weights(float * WQ, float* WK, float* WV, float* WO, float* WRMS,
                                      float* WH, float* WG, float* WOFFN, float* rmsWeight)
        {
            attnblock.load_attention_weights(WQ, WK, WV, WO, WRMS);
            ffn.load_FFN_weights(WH, WG, WOFFN, rmsWeight);
        }

        void transformer_inference(float *in) //out
        {
            attnblock.attention_forward(in, layer_intermediate);
            ffn.FFN(layer_intermediate, layer_output);
        }

        float* get_layer_output()
        {
            return layer_output;
        }

        int get_seq_len()
        {
            return attnblock.m_seq_len;
        }

        int get_dim()
        {
            return attnblock.m_dim;
        }


        TransformerEncoderBlock(int seq_len, int dim, int attn_num_heads, int ffn_in_features, int ffn_hidden_features, int ffn_out_features, float alphanorm)
        : attnblock(seq_len, dim, attn_num_heads,alphanorm),
        ffn(seq_len, ffn_in_features, ffn_hidden_features, ffn_out_features, alphanorm)
        {
            layer_intermediate = new float[seq_len * dim];
            layer_output = new float[seq_len * dim];
        }

        ~TransformerEncoderBlock()
        {
            if(layer_intermediate) delete[] layer_intermediate;
            if(layer_output) delete[] layer_output;
        }

};


// Transformer Encoder Block done;
// bias should be false
