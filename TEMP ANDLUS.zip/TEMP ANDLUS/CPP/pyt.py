from build import DynamicArray


x = DynamicArray.DynamicArray(10,20)

x.initialize()
x.double_it()
y = x.get_tensor()
print(y)

