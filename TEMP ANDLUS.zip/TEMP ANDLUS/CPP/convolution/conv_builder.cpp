#include"stream.hpp"
#include"convolution.hpp"
#include<nanobind/nanobind.h>
#include<vector>
#include<nanobind/ndarray.h>
#include <nanobind/stl/vector.h> // <--- CRITICAL: Enables C++ vector -> Python list conversion


namespace nb = nanobind;
using MyStream = hls_stream<Elementspacket, 1>;

NB_MODULE(CONV_BLOCK, m)
{
nb::class_<MyStream>(m, "fifo_stream")
        .def(nb::init<>())
        .def("empty", &MyStream::empty)
        .def("size", &MyStream::size)
        
        // --- HELPER: Python List/Array -> Stream ---
        .def("fill_stream", [](MyStream& self, const nb::ndarray<float, nb::c_contig>& input_array) {
            float* ptr = static_cast<float*>(input_array.data());
            size_t size = input_array.size();

            for(size_t i = 0; i < size; i++) {
                Elementspacket p;
                p.data[0] = ptr[i]; // Manually wrap float into packet
                self.write(p);
            }
        })

        // --- HELPER: Stream -> Python List ---
        // Reads everything currently in the stream and returns a Python list of floats
        .def("read_all", [](MyStream& self) {
            std::vector<float> result;
            while(!self.empty()) {
                try {
                    Elementspacket p = self.read();
                    result.push_back(p.data[0]); // Unwrap packet
                } catch (...) {
                    break;
                }
            }
            return result; // Nanobind converts this to a Python list automatically
        });



    nb::class_<ConvBlock>(m, "ConvBlock")
    .def(nb::init<>())
    .def("load_all_weights",[](ConvBlock& CB,
                               const nb::ndarray<>& w0,
                               const nb::ndarray<>& b0,
                               const nb::ndarray<>& w1,
                               const nb::ndarray<>& b1,
                               const nb::ndarray<>& w2,
                               const nb::ndarray<>& b2,
                               const nb::ndarray<>& w3,
                               const nb::ndarray<>& b3,
                               const nb::ndarray<>& w4,
                               const nb::ndarray<>& b4
                           ){
                                float* ptr_w0 = static_cast<float*>(w0.data());
                                float* ptr_b0 = static_cast<float*>(b0.data());
                                
                                float* ptr_w1 = static_cast<float*>(w1.data());
                                float* ptr_b1 = static_cast<float*>(b1.data());
                                
                                float* ptr_w2 = static_cast<float*>(w2.data());
                                float* ptr_b2 = static_cast<float*>(b2.data());
                                
                                float* ptr_w3 = static_cast<float*>(w3.data());
                                float* ptr_b3 = static_cast<float*>(b3.data());
                                
                                float* ptr_w4 = static_cast<float*>(w4.data());
                                float* ptr_b4 = static_cast<float*>(b4.data());


                                CB.load_all_weights(
                                    ptr_w0, ptr_b0,
                                    ptr_w1, ptr_b1,
                                    ptr_w2, ptr_b2,
                                    ptr_w3, ptr_b3,
                                    ptr_w4, ptr_b4
                                );
                           })
    .def("run", &ConvBlock::run);
    

}