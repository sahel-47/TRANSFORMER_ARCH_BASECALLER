#include"stream.hpp"
#include"MatrixInnerEngine.hpp"




template<
        unsigned int KernelDim,
        unsigned int IFMChannels,
        // unsigned int inputPrecision,
        unsigned int IPDim,
        unsigned int OPDim,
        unsigned int SIMD,
        unsigned int Stride
        >

class ConvInputGen_1D
{
    private:
        static constexpr unsigned int SIMD_MULTIPLE = IFMChannels/SIMD;
        static constexpr unsigned int BUFFER_SIZE = (KernelDim - 1) * SIMD_MULTIPLE;
        const unsigned int OUTPUT_SIZE = OPDim * KernelDim * SIMD_MULTIPLE;
        const unsigned int INPUT_SIZE = IPDim * SIMD_MULTIPLE;
        const unsigned int INITIAL_OCNT = BUFFER_SIZE + (Stride - 1);

        const unsigned int WINDOW_SIZE = KernelDim * SIMD_MULTIPLE;


        ElementsPacked<float,SIMD> input_buffer[BUFFER_SIZE];


    public:
        hls_stream<ElementsPacked<float,SIMD>,SIMD>& in;
        hls_stream<ElementsPacked<float,SIMD>,SIMD>& out;

        ConvInputGen_1D(hls_stream<ElementsPacked<float,SIMD>,SIMD>& input, hls_stream<ElementsPacked<float,SIMD>,SIMD>& output)
        :in{input},
         out{output}
         {

         }

         void generator()
         {



            unsigned int rp = 0;
            unsigned int wp = 0;
            unsigned int inp = 0;
            unsigned int offset = 0;
            unsigned int ocnt = (INITIAL_OCNT < WINDOW_SIZE ? INITIAL_OCNT:-1);

            for(int i = 0; i < OUTPUT_SIZE+1; i++)
            {
                bool const re  = i > 0;
                bool const we = ((i < WINDOW_SIZE) || (ocnt < SIMD_MULTIPLE * Stride));

                if(re)
                {
                    out.write(input_buffer[rp]);

                    if(++offset == WINDOW_SIZE)
                    {
                        rp += 1 + (Stride-1) * SIMD_MULTIPLE;
                        offset = 0;

                        if(rp >= BUFFER_SIZE)
                        {
                            rp -= BUFFER_SIZE;
                        }
                    }
                    else
                    {
                        if(++rp >= BUFFER_SIZE)
                        {
                            rp -= BUFFER_SIZE;
                        }
                    
                    }

                    if(++ocnt == WINDOW_SIZE)
                    {
                        ocnt = 0;
                    }
                    
                }

                if(we)
                {
                    if(++inp <= INPUT_SIZE)
                    {
                        input_buffer[wp] = in.read();
                        if(++wp >= BUFFER_SIZE)
                        {
                            wp = 0;
                        }
                    }
                }
            }

         }
        
};



template<
    typename T,
    unsigned OutputDim,
	unsigned  PaddingLeft,
	unsigned  PaddingRight,
	unsigned  PaddingTop,
	unsigned  PaddingBottom,
	unsigned  NumChannels,
	unsigned  SIMD,
	typename  In_t
>

class Padding_Unit
{
    private:
        hls_stream<T,SIMD>& in;
        hls_stream<T,SIMD>& out;

    public:

        Padding_Unit(hls_stream<T,SIMD>& in2, hls_stream<T,SIMD>& out2)
        : in{in2},
        out{out2}
        {
            
        }
        const unsigned  Folding = NumChannels/SIMD;

        void pad()
        {
            for(unsigned int x = 0; x < OutputDim; x++)
            {
                for(unsigned int sf = 0; sf < Folding; sf++)
                {
                    T outData ;
                    if( (x >= PaddingLeft) && (x < OutputDim - PaddingRight) ) {
				outData = in.read();
			    }

                else{
                    for(unsigned int p = 0; p < SIMD; p++){

                        outData[p] = 0.0f;
                    }
                }

                out.write(outData);

                }
            }
        }




};

// =========================================================
// GLOBAL CONFIGURATION
// =========================================================
#define SEQ_LEN_IN 12288
#define SIMD 1
#define PE 1

typedef ElementsPacked<float, SIMD> Elementspacket;

// =========================================================
// LAYER 0: 1 -> 64 (Stride 1)
// Output: 1024
// =========================================================
#define CL0_IN_CH    1
#define CL0_OUT_CH   64
#define CL0_KERNEL   5
#define CL0_STRIDE   1
#define CL0_PAD      2
#define CL0_IN_LEN   SEQ_LEN_IN
#define CL0_PAD_LEN  (CL0_IN_LEN + 2*CL0_PAD)
#define CL0_OUT_LEN  ((CL0_PAD_LEN - CL0_KERNEL)/CL0_STRIDE + 1) // = 1024

typedef Padding_Unit<Elementspacket, CL0_PAD_LEN, CL0_PAD, CL0_PAD, 0, 0, CL0_IN_CH, SIMD, Elementspacket> CL0_Pad_Unit;
typedef ConvInputGen_1D<CL0_KERNEL, CL0_IN_CH, CL0_PAD_LEN, CL0_OUT_LEN, SIMD, CL0_STRIDE> CL0_Gen;
typedef FloatingPackedWeights<SIMD, PE, ((CL0_OUT_CH/PE) * (CL0_IN_CH * CL0_KERNEL/SIMD))> CL0_Weight;
typedef BiasStore<float, CL0_OUT_CH, PE> CL0_Bias;
typedef MatrixInnerEngine<CL0_KERNEL * CL0_IN_CH, CL0_OUT_CH, SIMD, PE, Elementspacket, Elementspacket, CL0_Weight, float, CL0_Bias> CL0_Matrix_Engine;


// =========================================================
// LAYER 1: 64 -> 64 (Stride 1)
// Output: 1024
// =========================================================
#define CL1_IN_CH    64
#define CL1_OUT_CH   64
#define CL1_KERNEL   5
#define CL1_STRIDE   1
#define CL1_PAD      2
#define CL1_IN_LEN   CL0_OUT_LEN // Connects to L0 Output (1024)
#define CL1_PAD_LEN  (CL1_IN_LEN + 2*CL1_PAD)
#define CL1_OUT_LEN  ((CL1_PAD_LEN - CL1_KERNEL)/CL1_STRIDE + 1) // = 1024

typedef Padding_Unit<Elementspacket, CL1_PAD_LEN, CL1_PAD, CL1_PAD, 0, 0, CL1_IN_CH, SIMD, Elementspacket> CL1_Pad_Unit;
typedef ConvInputGen_1D<CL1_KERNEL, CL1_IN_CH, CL1_PAD_LEN, CL1_OUT_LEN, SIMD, CL1_STRIDE> CL1_Gen;
typedef FloatingPackedWeights<SIMD, PE, ((CL1_OUT_CH/PE) * (CL1_IN_CH * CL1_KERNEL/SIMD))> CL1_Weight;
typedef BiasStore<float, CL1_OUT_CH, PE> CL1_Bias;
typedef MatrixInnerEngine<CL1_KERNEL * CL1_IN_CH, CL1_OUT_CH, SIMD, PE, Elementspacket, Elementspacket, CL1_Weight, float, CL1_Bias> CL1_Matrix_Engine;


// =========================================================
// LAYER 2: 64 -> 128 (Stride 3)
// Output: 342
// =========================================================
#define CL2_IN_CH    64
#define CL2_OUT_CH   128
#define CL2_KERNEL   9
#define CL2_STRIDE   3
#define CL2_PAD      4
#define CL2_IN_LEN   CL1_OUT_LEN // Connects to L1 Output (1024)
#define CL2_PAD_LEN  (CL2_IN_LEN + 2*CL2_PAD)
#define CL2_OUT_LEN  ((CL2_PAD_LEN - CL2_KERNEL)/CL2_STRIDE + 1) // = 342

typedef Padding_Unit<Elementspacket, CL2_PAD_LEN, CL2_PAD, CL2_PAD, 0, 0, CL2_IN_CH, SIMD, Elementspacket> CL2_Pad_Unit;
typedef ConvInputGen_1D<CL2_KERNEL, CL2_IN_CH, CL2_PAD_LEN, CL2_OUT_LEN, SIMD, CL2_STRIDE> CL2_Gen;
typedef FloatingPackedWeights<SIMD, PE, ((CL2_OUT_CH/PE) * (CL2_IN_CH * CL2_KERNEL/SIMD))> CL2_Weight;
typedef BiasStore<float, CL2_OUT_CH, PE> CL2_Bias;
typedef MatrixInnerEngine<CL2_KERNEL * CL2_IN_CH, CL2_OUT_CH, SIMD, PE, Elementspacket, Elementspacket, CL2_Weight, float, CL2_Bias> CL2_Matrix_Engine;


// =========================================================
// LAYER 3: 128 -> 128 (Stride 2)
// Output: 171
// =========================================================
#define CL3_IN_CH    128
#define CL3_OUT_CH   128
#define CL3_KERNEL   9
#define CL3_STRIDE   2
#define CL3_PAD      4
#define CL3_IN_LEN   CL2_OUT_LEN // Connects to L2 Output (342)
#define CL3_PAD_LEN  (CL3_IN_LEN + 2*CL3_PAD)
#define CL3_OUT_LEN  ((CL3_PAD_LEN - CL3_KERNEL)/CL3_STRIDE + 1) // = 171

typedef Padding_Unit<Elementspacket, CL3_PAD_LEN, CL3_PAD, CL3_PAD, 0, 0, CL3_IN_CH, SIMD, Elementspacket> CL3_Pad_Unit;
typedef ConvInputGen_1D<CL3_KERNEL, CL3_IN_CH, CL3_PAD_LEN, CL3_OUT_LEN, SIMD, CL3_STRIDE> CL3_Gen;
typedef FloatingPackedWeights<SIMD, PE, ((CL3_OUT_CH/PE) * (CL3_IN_CH * CL3_KERNEL/SIMD))> CL3_Weight;
typedef BiasStore<float, CL3_OUT_CH, PE> CL3_Bias;
typedef MatrixInnerEngine<CL3_KERNEL * CL3_IN_CH, CL3_OUT_CH, SIMD, PE, Elementspacket, Elementspacket, CL3_Weight, float, CL3_Bias> CL3_Matrix_Engine;


// =========================================================
// LAYER 4: 128 -> 512 (Stride 2)
// Output: 86
// =========================================================
#define CL4_IN_CH    128
#define CL4_OUT_CH   512
#define CL4_KERNEL   5
#define CL4_STRIDE   2
#define CL4_PAD      2
#define CL4_IN_LEN   CL3_OUT_LEN // Connects to L3 Output (171)
#define CL4_PAD_LEN  (CL4_IN_LEN + 2*CL4_PAD)
#define CL4_OUT_LEN  ((CL4_PAD_LEN - CL4_KERNEL)/CL4_STRIDE + 1) // = 86

typedef Padding_Unit<Elementspacket, CL4_PAD_LEN, CL4_PAD, CL4_PAD, 0, 0, CL4_IN_CH, SIMD, Elementspacket> CL4_Pad_Unit;
typedef ConvInputGen_1D<CL4_KERNEL, CL4_IN_CH, CL4_PAD_LEN, CL4_OUT_LEN, SIMD, CL4_STRIDE> CL4_Gen;
typedef FloatingPackedWeights<SIMD, PE, ((CL4_OUT_CH/PE) * (CL4_IN_CH * CL4_KERNEL/SIMD))> CL4_Weight;
typedef BiasStore<float, CL4_OUT_CH, PE> CL4_Bias;
typedef MatrixInnerEngine<CL4_KERNEL * CL4_IN_CH, CL4_OUT_CH, SIMD, PE, Elementspacket, Elementspacket, CL4_Weight, float, CL4_Bias> CL4_Matrix_Engine;


class ConvBlock
{

    CL0_Weight w0;  CL0_Bias b0;
    CL1_Weight w1; CL1_Bias b1;
    CL2_Weight w2;  CL2_Bias b2;
    CL3_Weight w3; CL3_Bias b3;
    CL4_Weight w4; CL4_Bias b4;


    public:

        ConvBlock()
        {
        
         }   
    void load_all_weights(
        float* p_w0, float* p_b0,
        float* p_w1, float* p_b1,
        float* p_w2, float* p_b2,
        float* p_w3, float* p_b3,
        float* p_w4, float* p_b4
    ) {
        w0.load_weights(p_w0); b0.load_bias(p_b0);
        w1.load_weights(p_w1); b1.load_bias(p_b1);
        w2.load_weights(p_w2); b2.load_bias(p_b2);
        w3.load_weights(p_w3); b3.load_bias(p_b3);
        w4.load_weights(p_w4); b4.load_bias(p_b4);

    }



    // 3. THE FORWARD PASS (PIPELINE)
    // =========================================================
    // 3. THE FORWARD PASS (PIPELINE)
    // =========================================================
    // Note: Updated arguments to include the second template parameter 'SIMD'
    // 3. THE FORWARD PASS (PIPELINE)
    // =========================================================
    void run(hls_stream<Elementspacket, SIMD>& in_stream, hls_stream<Elementspacket, SIMD>& out_stream) {
        
        // --- Internal Streams ---
        hls_stream<Elementspacket, SIMD> s_L0_pad;
        hls_stream<Elementspacket, SIMD> s_L0_win;
        hls_stream<Elementspacket, SIMD> s_L0_out; 

        hls_stream<Elementspacket, SIMD> s_L1_pad;
        hls_stream<Elementspacket, SIMD> s_L1_win;
        hls_stream<Elementspacket, SIMD> s_L1_out;

        hls_stream<Elementspacket, SIMD> s_L2_pad;
        hls_stream<Elementspacket, SIMD> s_L2_win;
        hls_stream<Elementspacket, SIMD> s_L2_out;

        hls_stream<Elementspacket, SIMD> s_L3_pad;
        hls_stream<Elementspacket, SIMD> s_L3_win;
        hls_stream<Elementspacket, SIMD> s_L3_out;

        hls_stream<Elementspacket, SIMD> s_L4_pad;
        hls_stream<Elementspacket, SIMD> s_L4_win;

        // ================== LAYER 0 ==================
        CL0_Pad_Unit      l0_pad(in_stream, s_L0_pad);
        CL0_Gen           l0_gen(s_L0_pad, s_L0_win);
        // FIX: Pass CL0_OUT_LEN so it processes all 1024 time steps
        CL0_Matrix_Engine l0_eng(s_L0_win, s_L0_out, w0, b0, CL0_OUT_LEN);

        l0_pad.pad();
        l0_gen.generator();
        l0_eng.Multiply();

        // ================== LAYER 1 ==================
        CL1_Pad_Unit      l1_pad(s_L0_out, s_L1_pad);
        CL1_Gen           l1_gen(s_L1_pad, s_L1_win);
        // FIX: Pass CL1_OUT_LEN
        CL1_Matrix_Engine l1_eng(s_L1_win, s_L1_out, w1, b1, CL1_OUT_LEN);

        l1_pad.pad();
        l1_gen.generator();
        l1_eng.Multiply();

        // ================== LAYER 2 ==================
        CL2_Pad_Unit      l2_pad(s_L1_out, s_L2_pad);
        CL2_Gen           l2_gen(s_L2_pad, s_L2_win);
        // FIX: Pass CL2_OUT_LEN (342 steps)
        CL2_Matrix_Engine l2_eng(s_L2_win, s_L2_out, w2, b2, CL2_OUT_LEN);

        l2_pad.pad();
        l2_gen.generator();
        l2_eng.Multiply();

        // ================== LAYER 3 ==================
        CL3_Pad_Unit      l3_pad(s_L2_out, s_L3_pad);
        CL3_Gen           l3_gen(s_L3_pad, s_L3_win);
        // FIX: Pass CL3_OUT_LEN (171 steps)
        CL3_Matrix_Engine l3_eng(s_L3_win, s_L3_out, w3, b3, CL3_OUT_LEN);

        l3_pad.pad();
        l3_gen.generator();
        l3_eng.Multiply();

        // ================== LAYER 4 ==================
        CL4_Pad_Unit      l4_pad(s_L3_out, s_L4_pad);
        CL4_Gen           l4_gen(s_L4_pad, s_L4_win);
        // FIX: Pass CL4_OUT_LEN (86 steps)
        CL4_Matrix_Engine l4_eng(s_L4_win, out_stream, w4, b4, CL4_OUT_LEN); 

        l4_pad.pad();
        l4_gen.generator();
        l4_eng.Multiply();
    }


};