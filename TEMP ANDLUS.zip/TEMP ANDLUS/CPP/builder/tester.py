# 



import numpy as np


matrix1 = np.random.randint(low = 0, high= 20, size=(4,5))

print(matrix1)

print(matrix1.T)