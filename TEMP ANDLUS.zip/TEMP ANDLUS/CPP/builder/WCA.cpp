
            for(int i = 0; i < Total_iter; i++)
            {

                if(inp  < read_cycles) //very first row for K and Q fetched
                {
                    unsigned int q_val = query_stream.read();
                    unsigned int k_val = key_stream.read();

                    k_buf[k_w] = k_val;
                    q_buf[q_w] = q_val;
                    k_w++;
                    q_w++;
                    inp++;

                    if(inp == read_cycles)
                    {
                        key_row_count++;
                    }

                }

                else // FOR THE VERY FIRST VECTOR .... WHILE COMPUTING THE (N-1)th key vector ... we load the Nth vector//We stall compute until the entire vector is loaded
                { 


                    

                    if(internal_counter < write_cycles || free_flow_start)
                    {
                        
                        for(int i = 0; i < SIMD; i++)
                        //pragma UNROLL factor = SIMD
                        {
                            
                            acc_value+= q_buf[q_r+i] * k_buf[k_r + i];
                            
                        }

                        q_r += SIMD;
                        k_r += SIMD;

                        if(q_r == HDIM - 1)
                        {
                            q_r = 0;
                            attn_scores[attn_score_counter] = acc_value;
                            acc_value = 0;
                            attn_score_counter++;
                            
                        }

                        if(k_r >= total_k_size)
                        {
                            k_r -= total_k_size;
                        }

                        
                    }

                    if(internal_counter < read_cycles)
                    {
                        unsigned int k_val = query_stream.read();
                        k_buf[k_w] = k_val;
                        k_w++

                        if(internal_counter == read_cycles-1)
                        {
                            internal_counter = 0;
                            key_row_count++;

                            if(key_row_count == WIN_SIZE_RIGHT)
                            {
                                free_flow_start = true;
                            }

                            if(key_row_count == )
                        }

                        if(k_w == total_k_size)
                        {
                            
                        }
                        
                    }

                    internal_counter++;
                    
                }



            }
        }
