import torch
from build import MATRIX_INNER_ENGINE
import sys

# --- Configuration ---
T = 1024        # Total Sequence Length
H_DIM = 64      # Head Dimension
W_L = 127       # Left Window
W_R = 128       # Right Window

# 1. Generate Input Data
torch.manual_seed(42)
q_all = torch.randint(-100, 100, (T, H_DIM), dtype=torch.int32)
k_all = torch.randint(-100, 100, (T, H_DIM), dtype=torch.int32)

def get_expected_scores(query_idx):
    """Returns the PyTorch reference scores for a specific query."""
    start_idx = max(0, query_idx - W_L)
    end_idx = min(T, query_idx + W_R + 1)
    
    q_vec = q_all[query_idx]
    k_window = k_all[start_idx:end_idx]
    
    # Vectorized dot product (faster than loop)
    # (Window_Size, H) * (H) -> (Window_Size)
    scores = torch.matmul(k_window.float(), q_vec.float()).int().tolist()
    return scores

# 2. Setup Stream
q_numpy = q_all.numpy().flatten().astype('int32')
k_numpy = k_all.numpy().flatten().astype('int32')

q_stream = MATRIX_INNER_ENGINE.query_stream1()
k_stream = MATRIX_INNER_ENGINE.query_stream1()
out_stream = MATRIX_INNER_ENGINE.query_stream1()

q_stream.fill_stream(q_numpy)
k_stream.fill_stream(k_numpy)

print("🚀 Starting HLS Simulation...")
PLSSS = MATRIX_INNER_ENGINE.WindowedAttentionBlock(q_stream, k_stream, out_stream)
PLSSS.ATTENTION()
print("✅ Simulation Complete. Verifying outputs...")

# 3. Full Matrix Comparison
total_errors = 0

for q_idx in range(T):
    # A. Get Golden Reference
    ref_scores = get_expected_scores(q_idx)
    expected_count = len(ref_scores)
    
    # B. Read exactly that many from HLS
    hls_scores = []
    try:
        for _ in range(expected_count):
            # Check if stream is empty before reading to avoid hang
            if out_stream.empty():
                print(f"❌ CRITICAL: Stream empty early at Q{q_idx}!")
                sys.exit(1)
            hls_scores.append(out_stream.read())
    except Exception as e:
        print(f"💥 Crash reading Q{q_idx}: {e}")
        break

    # C. Compare
    if ref_scores != hls_scores:
        print(f"❌ Mismatch at Query {q_idx}")
        print(f"   Expected len: {len(ref_scores)}, Got: {len(hls_scores)}")
        print(f"   Las 5 Ref: {ref_scores[:5]}")
        print(f"   Las 5 HLS: {hls_scores[:5]}")
        total_errors += 1
        # Optional: Stop after first error to debug
        if total_errors > 5: 
            print("Too many errors, stopping.")
            break
    
    if q_idx % 100 == 0:
        print(f"   Verified {q_idx}/{T} queries...")

if total_errors == 0:
    print(f"🏆 SUCCESS! All {T} queries matched perfectly.")
else:
    print(f"💀 FAILED with {total_errors} errors.")