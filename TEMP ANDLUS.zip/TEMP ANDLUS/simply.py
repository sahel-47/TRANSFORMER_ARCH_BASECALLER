from collections import OrderedDict
import torch.nn as nn
import toml 
from pathlib import Path
layers = {}

def register(layer):

    layer.name = layer.__name__.lower()

    layers[layer.name] = layer

    return layer

@register(nn.ReLU)

@register
class Convolution(nn.Module):
    def __init__(self, insize, size, bias, winlen, stride, padding, activation = None, norm = None):
        super().__init__()

        self.conv = nn.Conv1d(
            in_channels= insize,
            out_channels= size,
            bias=bias,
            kernel_size = winlen,
            stride= stride,
            padding=padding,
        )

        self.activation = layers[activation]() 

        self.batchnorm = nn.BatchNorm1d(size)

    def forward(self, x):

        x = self.conv(x)
        x = self.batchnorm(x)
        return self.activation(x)
    



@register
class Serial(nn.Sequential):
    def __init__(self, sublayers):
        super().__init__(*sublayers)

    def forward(self, x, debug_mode = False):
        if debug_mode:
            f_maps = []
            for layer in self:
                x = layer(x)
                f_maps.append(x)

            return x, f_maps
        return super().forward(x)
    

@register
class Stack(Serial):

    @classmethod
    def from_dict(cls, model_dict, layers_type = None):
        return cls([from_dict(model_dict["layer"], layers_type) for _ in range(model_dict["depth"])])
    


@register
class NamedSerial(nn.Sequential):
    def __init__(self, layers):
        super().__init__(OrderedDict(layers))

    @classmethod
    def from_dict(cls, model_dict, layers_type = None):

        return cls({k : from_dict(v, layers_type) for k, v in model_dict.items()})
    

def from_dict(model_dict, layers_type = None):

    if not isinstance(model_dict, dict):
        return model_dict
    
    model_dict = model_dict.copy()

    type_name = model_dict.pop("type")

    if(layers_type == None):
        layers_type = layers
    typ = layers_type[type_name]

    if hasattr(typ, "from_dict"):
        return typ.from_dict(model_dict, layers_type)


    if "sublayers" in model_dict:
        sublayers = model_dict["sublayers"]
        model_dict["sublayers"] = [from_dict(x, layers_type) for x in sublayers] if isinstance(sublayers, list) else from_dict(sublayers, layers_type)

    
    try:
        layer = typ(**model_dict)

    except:
        raise Exception("COOKED BRO")
    
    return layer

__dir__ = Path(__file__).parent 
__models_dir__ = __dir__ / "models"
__data_dir__ = __dir__ / "data"
config_path = __models_dir__ / "test_config1.toml"

print(layers)

config_dict = toml.load(config_path)

model = from_dict(config_dict["model"]["encoder"])


print(model)