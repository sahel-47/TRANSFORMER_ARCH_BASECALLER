import torch 
import torch.nn as nn
import numpy as np
from CPP.transformer.build import TRANSFORMER_ENCODER_BLOCK 
from transformer import TransformerEncoderLayer



def verify():

    SEQ_LEN = 1024
    D_MODEL = 512
    NHEAD = 8
    DIM_FEEDWORWARD = 2048
    DEEPNORM_ALPHA = 2.4494897
    DEEPNORM_BETA = 1.0

    print(f"--- Setup: Seq={SEQ_LEN}, Dim={D_MODEL}, Heads={NHEAD} ---")

    torch.manual_seed(42)
    torch_model = TransformerEncoderLayer(
        D_MODEL,
        NHEAD,
        DIM_FEEDWORWARD,
        DEEPNORM_ALPHA,
        DEEPNORM_BETA, attn_window=[127, 128]
    ).eval()


    cpp_model = TRANSFORMER_ENCODER_BLOCK.transformer_encoder_block(
        SEQ_LEN, D_MODEL, NHEAD,
        D_MODEL, DIM_FEEDWORWARD, D_MODEL,
        DEEPNORM_ALPHA
    )

    print()
    print("C++ model instantiated")

    print("EXTRACTING AND CONVERTING WEIGHTS.......")

    def to_cpp(t):
    # This ensures it is Flat in memory, Float32, and on CPU
        return np.ascontiguousarray(t.detach().cpu().numpy(), dtype=np.float32)
    

    wqkv = torch_model.attn_block.Wqkv.weight

    q_tensor, k_tensor, v_tensor = torch.chunk(wqkv, 3, dim=0)

    wq = to_cpp(q_tensor)
    wk = to_cpp(k_tensor)
    wv = to_cpp(v_tensor)

    wo = to_cpp(torch_model.attn_block.out_proj.weight)
    
    rms1 = to_cpp(torch_model.rms_norm1.weight)

    fused_weight = torch_model.ff.linear1.weight
    w_hidden_tensor, w_gate_tensor = torch.chunk(fused_weight, 2, dim=0)
    wh = to_cpp(w_hidden_tensor) 
    wg = to_cpp(w_gate_tensor)
    woffn = to_cpp(torch_model.ff.linear2.weight)

    rms2 = to_cpp(torch_model.rms_norm2.weight)

    cpp_model.load_transformer_weights(wq, wk, wv, wo, rms1, wh, wg, woffn, rms2)


    x_torch = torch.rand(1, SEQ_LEN, D_MODEL)
    x_numpy = np.ascontiguousarray(x_torch.squeeze(0).numpy(), dtype=np.float32)

    with torch.no_grad():
        y_torch = torch_model(x_torch)
        y_torch = y_torch.squeeze(0).numpy()


    cpp_model.transformer_inference(x_numpy)
    y_cpp = cpp_model.get_layer_output()


    diff = np.abs(y_torch - y_cpp)
    max_diff = diff.max()
    print("\n--- Results ---")
    print(f"Max Absolute Diff: {max_diff:.7f}")


    if max_diff < 1e-4:
        print("✅ SUCCESS: Implementations Match!")
    else:
        print("❌ FAILURE: Mismatch Detected.")
        print("Top 3 common causes:")
        print("1. Swapped Gate/Hidden weights in FFN (Try swapping wg/wh)")
        print("2. RoPE Rotation logic mismatch (Check idx1/idx2 in C++)")
        print("3. QKV Split order (Is it Q-K-V or Q-V-K?)")





verify()


