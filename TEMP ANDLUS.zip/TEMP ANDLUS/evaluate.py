import torch
import parasail # highly optimized C library wrapper for sequence alignment (Smith-Waterman algorithm).
from pathlib import Path
from dataclasses import dataclass
from collections import defaultdict
from argparse import ArgumentDefaultsHelpFormatter, ArgumentParser
import pandas as pd
from tqdm import tqdm
from utils import decode_ref, init, load_model, permute
from data import load_data, ComputeSettings, DataSettings, ModelSetup
import re
import textwrap

@dataclass
class AlignResult:
    accuracy: float = 0
    num_correct: int = 0
    num_mismatches: int = 0
    num_insertions: int = 0
    num_deletions: int = 0
    ref_len: int = 0
    seq_len: int = 0
    align_ref_start: int = 0
    align_ref_end: int = 0
    align_seq_start: int = 0
    align_seq_end: int = 0


def align(*, ref, seq):
    if not seq:
        return AlignResult()

    res = parasail.sw_trace_striped_32(seq, ref, 8, 4, parasail.dnafull)

    cigar = res.cigar.decode.decode()
    counts = defaultdict(int)
    for cnt, op in re.findall(r"(\d+)([A-Z\W])", cigar):
        counts[op] += int(cnt)

    # Sometimes parasail.SW will start with xD and we need to handle this explicitly
    del_start = int(match[0]) if (match := re.findall(r"^(\d+)D", cigar)) else 0
    counts['D'] -= del_start

    ref_start = res.end_ref - counts['='] - counts['X'] - counts['D'] + 1
    seq_start = res.end_query - counts['='] - counts['X'] - counts['I'] + 1

    return AlignResult(
        accuracy=counts["="] / sum(counts.values()),
        num_correct=counts["="],
        num_mismatches=counts["X"],
        num_insertions=counts["I"],
        num_deletions=counts["D"],
        ref_len=len(ref),
        seq_len=len(seq),
        align_ref_start=ref_start,
        align_ref_end=res.end_ref,
        align_seq_start=seq_start,
        align_seq_end=res.end_query,
    )

__current_dir__ = Path(__file__).parent

class Config:
    model_directory = __current_dir__/"models"/"dna_r10.4.1_e8.2_400bps_sup@v5.0.0"
    data_directory =  __current_dir__/"data"/"example_data_dna_r10.4.1_v0"/"validation"
    results_directory = __current_dir__/"results"

    weights = "0"
    device = "cuda"

    dataset = "valid"
    num_chunks = 100
    batchsize = 1
    seed = 42 
    standardise = True


def evaluation(cfg:Config):

    init(cfg.seed, cfg.device)

    print(f"Loading the Model from {cfg.model_directory}")

    model = load_model(cfg.model_directory, cfg.device) # Not kept 0

    standardisation = model.config.get("standardisation", {}) if cfg.standardise else {}
    model_setup = ModelSetup(
        n_pre_context_bases=getattr(model, "n_pre_context_bases", 0),
        n_post_context_bases=getattr(model, "n_post_context_bases", 0),
        standardisation=standardisation,
    )

    print(f"* Standardization: mean={model_setup.standardisation.get('mean', 0.0)}, "
          f"stdev={model_setup.standardisation.get('stdev', 1.0)}")
    
    print(f"* Loading validation chunks......")
    compute_settings  = ComputeSettings(batch_size=cfg.batchsize, num_workers=4, seed=cfg.seed)

    if cfg.dataset == "valid":

        data_settings = DataSettings(cfg.data_directory, cfg.num_chunks * 100, cfg.num_chunks, None)
        _, dataloader = load_data(data_settings, model_setup, compute_settings)

    else:
        # Load training data
        data_settings = DataSettings(cfg.directory, cfg.chunks, cfg.chunks, None)
        dataloader, _ = load_data(data_settings, model_setup, compute_settings) 



    print(f"* INFERENCING")

    seqs = []
    targets = []


    with torch.no_grad(): #with torch.inference_mode():

        for data, target, *_ in tqdm(dataloader, total = cfg.num_chunks//cfg.batchsize):

            targets.extend(torch.unbind(target, 0))

            data = data.type(torch.float32).to(cfg.device)


            log_probs = model(data)


            if hasattr(model, 'decode_batch'):

                seqs.extend(model.decode_batch(log_probs))

            else:

                 seqs.extend([model.decode(p) for p in permute(log_probs, 'TNC', 'NTC')])

            
    print("* Decoding references...")
    refs = [decode_ref(target, model.alphabet) for target in targets]

    # 6. Run Alignment (The Grading)
    print("* Aligning sequences...")
    # This runs the 'align' function defined above on every pair
    alignments = pd.DataFrame([align(ref=ref, seq=seq) for ref, seq in zip(refs, seqs)])

    # 7. Print Final Report
    print(textwrap.dedent(f"""
        ===========================================
        FINAL RESULTS
        ===========================================
        * num_chunks      {len(alignments)}
        * accuracy        {alignments.accuracy.mean():.2%}
        * sub-rate        {(alignments.num_mismatches / alignments.num_correct).mean():.2%}
        * ins-rate        {(alignments.num_insertions / alignments.num_correct).mean():.2%}
        * del-rate        {(alignments.num_deletions / alignments.num_correct).mean():.2%}
        * seq_len         {alignments.seq_len.mean():.1f}
        * ref_len         {alignments.ref_len.mean():.1f}
        ===========================================
        """))



cfg = Config(

)

evaluation(cfg)