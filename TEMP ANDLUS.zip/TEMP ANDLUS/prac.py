import torch 
import torch.nn as nn
from collections import OrderedDict


layers = {}

def register(layer):

    layer.name = layer.__name__.lower()
    layers[layer.name] = layer 
    return layer


register(nn.ReLU)
register(nn.Tanh)



@register
class Linear(nn.Module):
    def __init__(self, in_features, out_features, bias = True):
        super().__init__()

        self.linear = nn.Linear(in_features=in_features, out_features=out_features, bias = bias)


    def forward(self, x):

        return self.linear(x)
    


@register
class Serial(nn.Sequential):
    def __init__(self, sublayers):
        super().__init__(*sublayers)

    def forward(self, x, return_intermediate = False):

        if return_intermediate:
            fmaps = []

            for layers in self:
                x = layers(x)
                fmaps.append(x)
            return x, fmaps
        
        return super().forward(x)
    


@register
class NamedSerial(nn.Sequential):

    @classmethod
    def from_dict(cls, model_dict, layer_types=None):
        return cls({k : from_dict(v) for k, v in model_dict.items()})
    
    def __init__(self,layers):
        super().__init__(OrderedDict(layers))



@register
class Stack(Serial):    
    
    @classmethod
    def from_dict(cls,model_dict, layer_types=None):
        return cls([from_dict(model_dict["layer"], layer_types) for _ in range(model_dict["depth"])])
    





def from_dict(model_dict, layer_types):

    if not isinstance(model_dict, dict):
        return model_dict
    
    model_dict = model_dict.copy()

    type_name = model_dict.pop("type")

    if layer_types is None:
        layer_types = layers 

    typ = layers[type_name]

    if hasattr(typ, "from_dict"):

        return typ.from_dict(model_dict)
    
    if "sublayers" in model_dict:

        sublayers= model_dict["sublayers"]

        model_dict["sublayers"] = [
            from_dict(x, layer_types) for x in sublayers 
        ] if isinstance(sublayers, list) else from_dict(sublayers, layer_types)

    try:
        layer = typ(**model_dict)
    except Exception as e:
        raise Exception(f'Failed to build layer of type {typ} with args {model_dict}') from e
    
    return layer


        