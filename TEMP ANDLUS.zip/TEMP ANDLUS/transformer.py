import torch
import torch.nn as nn
from einops import rearrange, repeat
from typing import Optional
import torch.nn.functional as F
from Seqdist import SeqdistModel, CTC_CRF
# from flash_attn.layers.rotary import RotaryEmbedding
from nn import from_dict, register, LinearCRFEncoder, MakeContiguous, Module, Permute, Serial
import types
import koi


class RMSNorm(nn.Module):
    def __init__(self, hidden_size, eps = 1e-5, zero_centered_weight = False, device = None, dtype = None):
        super().__init__()
    
        kwargs = {"device": device, "dtype": dtype}
        self.eps = eps 
        self.zero_centered_weight = zero_centered_weight
        self.weight = torch.nn.Parameter(torch.empty(hidden_size, **kwargs))
        self.bias = None
        self.reset_parameters()

    def rms_norm(self, x, weight, bias, residual =None, eps = 1e-6,prenorm = False, zero_centered_weight = False, upcast = False):
        
        """
        RMS norm is applied twice in a transformer Encoder block ... once after Multi head attention after residual add ..... and once after Feed Forward Network after residual add

        X' = X/RMS(X)   RMS(X) = 1/sqrt((ΣX**2)/N) --- > this implements RMS norm
    
        """

        dtype = x.dtype

        if upcast:
            x = x.float()
            weight = weight.float()
            bias = bias.float() if bias is not None else None
            residual = residual.float() if residual is not None else residual

        if zero_centered_weight:
            weight = weight + 1.0

        if residual is not None:
            x = (x + residual).to(dtype)

        rms_norm_val = 1/torch.sqrt((x.square()).mean(dim = -1, keepdim = True)+eps)
            # Just a single value per sequence  will give out an output of shape (BATCH, SEQ_LEN, 1) ----> Will be broadcasted accross all the features

        out = ((x * rms_norm_val*weight)) + bias if bias is not None else (x*rms_norm_val*weight)

        return out

    def reset_parameters(self):
        if not self.zero_centered_weight:
            torch.nn.init.ones_(self.weight)
        else:
            torch.nn.init.zeros_(self.weight)


    def forward(self, x, residual = None, prenorm = False):

        return self.rms_norm(x, self.weight, self.bias, residual, self.eps, prenorm = prenorm, zero_centered_weight=self.zero_centered_weight)
    


class RoPE(nn.Module):
    def __init__(self, dim, base = 10000.0, interleaved = False, scale_base = None, device = None):
        super().__init__()
        self.dim = dim ### DIM OF ONE HEAD
        self.base = base 
        inv_freq = self._inv_freq(device)
        self.register_buffer("inv_freq", inv_freq, persistent=False)

        self.interleaved = interleaved



    def _inv_freq(self, device = None):

        return 1.0/(
            self.base**(torch.arange(0, self.dim, 2, device= device, dtype =torch.float32)/self.dim)
        )

    def rotate(self, x , interleaved = False):
        
        if not interleaved:
            x1,x2 = x.chunk(2, dim = -1)
            return torch.cat((-x2,x1), dim = -1)

    def rope_compute(self, x, cos, sin ,interleaved = False):
        """
        x : (BATCH SIZE, SEQ_LEN, N_HEADS, H_DIM)
        cos, sin: (seq_len, H_DIM/2) or (BATCH_SIZE, SEQ_LEN, H_DIM/2)
        
        """
        cos_sin_dim  = cos.shape[-1]*2

        assert cos_sin_dim == x.shape[-1]

        cos = repeat(cos, "... d -> ... 1 (2 d)" if not interleaved else "... d -> ... 1 (d 2)")
        sin = repeat(sin, "... d -> ... 1 (2 d)" if not interleaved else "... d -> ... 1 (d 2)") 

        return torch.cat(
            [x[..., :cos_sin_dim]*cos + self.rotate(x[..., :cos_sin_dim],interleaved)*sin]
            ,dim=-1

        )
    
    def _cos_sin_table(self, seqlen, device = None, dtype = None):

        if self.inv_freq.dtype != torch.float32:
            inv_freq = self._inv_freq(device=device)

        else:
            inv_freq = self.inv_freq 

        t = torch.arange(seqlen, device=device, dtype=torch.float32)

        freqs = torch.outer(t, inv_freq)

        self.cos_table = torch.cos(freqs).to(dtype)
        self.sin_table = torch.sin(freqs).to(dtype)

    

    def forward(self, qkv, num_heads_q :Optional[int] = None):
        seq_len = qkv.shape[1]
        batch, seqlen, three, nheads, headdim = qkv.shape

        qk = qkv[:,:,:2].reshape(batch, seqlen, -1, headdim)


        self._cos_sin_table(seq_len, device = qkv.device, dtype = qkv.dtype)

        q = self.rope_compute(
            qk,
            self.cos_table,
            self.sin_table,
            interleaved=self.interleaved
        )

        return torch.cat([q.reshape(batch, seqlen, 2, nheads, headdim), qkv[:,:,2:3,:,:]],dim = 2)


def sliding_window_mask(seq_len, window, device):
    band = torch.full((seq_len, seq_len), fill_value=1.0)
    band = torch.triu(band, diagonal=-window[0])
    band = band * torch.tril(band, diagonal=window[1])
    band = band.to(torch.bool).to(device)
    return band

class MultiHeadAttention(nn.Module):
    def __init__(self, d_model, n_head, qkv_bias = False, out_bias = False, rotary_dim = None, attn_window = None):
        super().__init__()

        assert d_model%n_head == 0, "d_model must be divisible by head"

        self.d_model = d_model
        self.n_head = n_head
        self.head_dim = d_model//n_head
        self.rotary_dim = self.head_dim # I THINK FOR BONITO TRANSOFMER IT REMAINS THE SAME

        self.Wqkv = nn.Linear(d_model, 3*d_model, bias = qkv_bias)
        self.out_proj = nn.Linear(d_model, d_model, bias = out_bias)

        self.RotaryEmb = RoPE(self.rotary_dim, interleaved=False)
        self.attn_window = (-1, -1) if attn_window is None else tuple(attn_window)


    def attn_func(self, qkv):

            q, k, v = torch.chunk(qkv.permute(0,2,3,1,4), chunks = 3, dim = 1)
            mask = sliding_window_mask(qkv.shape[1],self.attn_window, q.device)
            attn_output = F.scaled_dot_product_attention(q,k,v, attn_mask=mask)
            attn_output = attn_output.permute(0,1,3,2,4) #(Batch, Heads, Time, Dim) ------> (Batch, Time, Heads, Dim).

            return attn_output
        
    def forward(self,x):

            N, T, _ = x.shape

            qkv = self.Wqkv(x).view(N,T,3,self.n_head, self.head_dim)
            qkv = self.RotaryEmb(qkv)
            attn_output = self.attn_func(qkv).reshape(N,T,self.d_model)
            out = self.out_proj(attn_output)
            return out
    

class GatedMLP(nn.Module):
    def __init__(self, in_features, hidden_features = None, out_features = None, activation = F.sigmoid, bias1 = False, bias2 = False, multiple_of= 128, return_residual = False, device = None, dtype = None):
        super().__init__()
        factory_kwargs = {"device": device, "dtype" : dtype}

        out_features = out_features if out_features is not None else in_features
        hidden_features = hidden_features if hidden_features else int(8 * in_features/3)
        hidden_features = (hidden_features + multiple_of - 1)//multiple_of * multiple_of
        self.return_residual = return_residual
        self.linear1 = nn.Linear(in_features, 2 * hidden_features, bias=bias1, **factory_kwargs)
        self.activation = activation
        self.linear2 = nn.Linear(hidden_features, out_features, bias = bias2, **factory_kwargs)


    def forward(self, x):
        y = self.linear1(x)
        if self.activation == F.sigmoid:
            y = F.glu(y, dim=-1)

        elif self.activation == F.silu:
            y, gate = torch.chunk(y, 2, dim = -1)

            y = y * F.silu(gate)
        
        else:
            y, gate = y.chunk(2, dim=-1)
            y = y * self.activation(gate)

        y = self.linear2(y)

        return y if not self.return_residual else (y,x)

        
@register
class TransformerEncoderLayer(nn.Module):
    def __init__(self, d_model, nhead, dim_feedforward, deepnorm_alpha, deepnorm_beta, attn_window = None):

        super().__init__()

        self.kwargs = {
            "d_model": d_model,
            "nhead": nhead,
            "dim_feedforward": dim_feedforward,
            "deepnorm_alpha": deepnorm_alpha,
            "deepnorm_beta": deepnorm_beta,
            "attn_window": attn_window
        }

        self.attn_block = MultiHeadAttention(d_model,
                                             nhead,
                                             False,
                                             False, #set true 
                                             attn_window=attn_window)
        
        self.ff = GatedMLP(d_model, dim_feedforward, d_model,
                           F.silu, False, False, 1)


        self.rms_norm1 = RMSNorm(d_model)
        self.rms_norm2 =RMSNorm(d_model)


        self.register_buffer("deepnorm_alpha", torch.tensor(deepnorm_alpha))
        self.reset_parameters()

    def reset_parameters(self):
        db = self.kwargs["deepnorm_beta"]
        d_model = self.kwargs["d_model"]
        torch.nn.init.xavier_normal_(self.ff.linear1.weight, gain=db)
        torch.nn.init.xavier_normal_(self.ff.linear2.weight, gain=db)
        torch.nn.init.xavier_normal_(self.attn_block.out_proj.weight, gain=db)
        torch.nn.init.xavier_normal_(self.attn_block.Wqkv.weight[2*d_model:], gain=db)
        torch.nn.init.xavier_normal_(self.attn_block.Wqkv.weight[:2*d_model], gain=1)



    def forward(self, x):

        x = self.rms_norm1(self.attn_block(x), self.deepnorm_alpha * x)
        x = self.rms_norm2(self.ff(x), self.deepnorm_alpha * x)

        return x


    def to_dict(self, include_weights=False):
        if include_weights:
            raise NotImplementedError
        return self.kwargs








def use_koi(self, **kwargs):
    # koi needs modified LinearCRFLayer settings
    def _expand_blanks(m):
        if isinstance(m, LinearCRFEncoder):
            m.expand_blanks = False
    self.encoder.apply(_expand_blanks)
    self.encoder = Serial([
        self.encoder,
        Permute([1, 0, 2]),
        MakeContiguous(),
    ])


class Model(SeqdistModel):

    def __init__(self, config):
        seqdist = CTC_CRF(
            state_len=config['model']['seqdist']['state_len'],
            alphabet=config['model']['seqdist']['alphabet']
        )
        if 'type' in config['model']['encoder']: #new-style config
            encoder = from_dict(config['model']['encoder'])
        # else: #old-style
            # encoder = rnn_encoder(seqdist.n_base, seqdist.state_len, insize=config['input']['features'], **config['encoder'])

        super().__init__(encoder, seqdist,  n_pre_post_context_bases=config.get('input', {}).get('n_pre_post_context_bases'))
        self.config = config

    def use_koi(self, **kwargs):
        self.encoder = koi.lstm.update_graph(
            self.encoder,
            batchsize=kwargs["batchsize"],
            chunksize=kwargs["chunksize"] // self.stride,
            quantize=kwargs["quantize"],
        )



# def Model(config):
#     model_config = {k: v for k, v in config["model"].items() if k != "package"}
#     model = from_dict(model_config)
#     model.config = config
#     model.use_koi = types.MethodType(use_koi, model)
#     return model





    































# torch.manual_seed(0)


# x = torch.randn(1,3,3,3,2)


# rope = RoPE(2,10000,False)

# output = rope(x)


# print(f"X IS: {x}")
# print(
# )

# print(f"Output is: {output}")






# torch.manual_seed(0)
# rms_layer = RMSNorm(4)
# x = torch.rand((1,2,4),dtype = torch.float32)

# print("INPUT TENSOR: ",x)

# output = rms_layer(x)

# print()

# print("OUTPUT TENSOR:",output)

# print(rms_layer.weight)







# class BONITOMultiHeadAttention(nn.Module):
#     def __init__(self, d_model, nhead, qkv_bias=False, out_bias=True, rotary_dim=None, attn_window=None):
#         super().__init__()
#         assert d_model % nhead == 0, "d_model must be divisible by nhead"

#         self.d_model = d_model
#         self.nhead = nhead
#         self.head_dim = d_model // nhead
#         self.rotary_dim = self.head_dim if rotary_dim is None else rotary_dim

#         self.Wqkv = torch.nn.Linear(d_model, 3 * d_model, bias=qkv_bias)
#         self.out_proj = torch.nn.Linear(d_model, d_model, bias=out_bias)

#         self.rotary_emb = RotaryEmbedding(self.rotary_dim, interleaved=False)
#         self.attn_window = (-1, -1) if attn_window is None else tuple(attn_window)

#     def attn_func(self, qkv):
      
#             q, k, v = torch.chunk(qkv.permute(0, 2, 3, 1, 4), chunks=3, dim=1)
#             mask = sliding_window_mask(qkv.shape[1], self.attn_window, q.device)
#             attn_output = F.scaled_dot_product_attention(q, k, v, attn_mask=mask)
#             attn_output = attn_output.permute(0, 1, 3, 2, 4)
#             return attn_output

#     def forward(self, x):
#         N, T, _ = x.shape

#         qkv = self.Wqkv(x).view(N, T, 3, self.nhead, self.head_dim)

#         qkv = self.rotary_emb(qkv)

#         attn_output = self.attn_func(qkv).reshape(N, T, self.d_model)

#         out = self.out_proj(attn_output)

#         return out




# FULL_ATTN = MultiHeadAttention(512, 8, False, False, None, [127, 128])

# BONITO_ATTN = BONITOMultiHeadAttention(512,8,False, False, None, [127,128])

# FULL_ATTN.load_state_dict(BONITO_ATTN.state_dict())

# torch.manual_seed(0)

# tensor = torch.randn((1,1000,512), dtype = torch.float32)

# BONITO_ATTN = BONITO_ATTN.cuda()
# FULL_ATTN.eval()
# BONITO_ATTN.eval()

# output1 = FULL_ATTN(tensor)

# tensor = tensor.cuda()


# output2 = BONITO_ATTN(tensor)

# output2 = output2.cpu()


# print(torch.allclose(output1, output2,atol=1e-5))




# tensor = tensor.cuda()

# BONITO_ATTN = BONITOMultiHeadAttention(512,8,False,False,None,[127,128])
# BONITO_ATTN = BONITO_ATTN.cuda()
# output2 = BONITO_ATTN(tensor)


# output2 = output2.cpu()



# print(torch.allclose(output, output2, atol=1e-6))


# print(output2[0][4][15])
# print(output[0][4][15])

# # rotary_dim = 64

# bonito_ROPE = RotaryEmbedding(rotary_dim, interleaved=False,device="cuda")
# my_rope = RoPE(rotary_dim, interleaved=False)

# torch.manual_seed(0)
# x = torch.rand((1,1000,3,8,64))


# golden_x = bonito_ROPE(x.to("cuda"))

# my_x = my_rope(x)


# print(golden_x.shape)
# print(my_x.shape)

# golden_x = golden_x.cpu()

# tol = 1e-5

# print(torch.allclose(my_x, golden_x, atol =tol))

# # tensor_a = golden_x[:,:,0,:,:] # (1,1000,8,64)
# # tensor_b = golden_x[:,:,1,:,:]


# # my_tensor1,my_tensor2 = torch.chunk(my_x,2,2)

# # tol = 1e-5
# # print(torch.allclose(tensor_a, my_tensor1, atol=tol))
# # print(torch.allclose(tensor_b, my_tensor2, atol=tol))